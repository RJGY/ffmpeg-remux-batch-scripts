<blockquote style="border-left: 5px solid #ffe4e1;">

<b> <h1 style="font-size: 40px; color: #FFD700;">[💮] Support Me!</h1> </b>

<h2 style="color: #89C7DF; font-weight: bold;"><span>[📢]</span> <span style="text-decoration: underline;">Connect with me:</span></h2>
<blockquote style="padding-bottom: 5px; padding-top: 5px; border-left: 5px solid #ffe4e1;">
<hr>
<ul style="padding-left: 30px;">
    <li><strong>Website:</strong> <a href="https://russie.me/">https://russie.me/</a></li>
    <li><strong>Discord:</strong> russie#0001 | <a href="https://discord.gg/russie">discord.gg/russie</a></li>
    <li><strong>Instagram:</strong> @russie</li>
    <li><strong>YouTube:</strong> @russie</li>
</ul>
</blockquote>

<br>

<h2 style="color: #89C7DF; font-weight: bold;"><span>[🔧]</span> <span style="text-decoration: underline;">Usage:</span></h2>
<blockquote style="padding-bottom: 5px; padding-top: 5px; border-left: 5px solid #ffe4e1;">
<hr>
In order to modify the script to convert as you wish, you can modify the configuration file to convert your files to the desired extension/container. To initiate, simply drag and drop selected file(s) onto the script(s).

<br>

<table>
    <tr>
        <th>Script</th>
        <th>Description</th>
    </tr>
        <tr>
        <td><strong>Font Conversion</strong></td>
        <td>Converts font files between font formats (ttf, otf, woff, woff2, etc).</td>
    </tr>
            <tr>
        <td><strong>Metadata Removal</strong></td>
        <td>Removes all non-essential metadata from your file(s).</td>
    </tr>
            <tr>
        <td><strong>Re-Encoding</strong></td>
        <td>This is NOT a lossless process, re-encoding takes the existing file and encode it again with different codec, bitrate, or other settings.</td>
    </tr>
            <tr>
        <td><strong>Re-Muxing</strong></td>
        <td>This IS a lossless process, re-muxing extracts the file's existing streams from a video container and puts them into a new container without altering the original codec or quality.</td>
    </tr>
            <tr>
        <td><strong>Upscaler</strong></td>
        <td>This is NOT the same as AI-Upscaling as it does not involve any models, this is simply using FFMpeg algorithms to upscale the dimentions of your video, this is done to "trick" video sharing platforms such as YouTube to give your video a higher bitrate.</td>
</table>
</blockquote>
<br>

Scripts by RJGY
</blockquote>